
/**
 * COGNIZANT START APP.JS
 */

(function() {
  var MKBL;

  MKBL = {};

  $.expr[':'].Contains = function(a, i, m) {
    return (a.textContent || a.innerText || '').toUpperCase().indexOf(m[3].toUpperCase()) >= 0;
  };


  /**
   * Remove Classes based on partial matches
   * @param  {[type]} removals  classes you want to remove
   * @param  {[type]} additions classes you want to add
   */

  $.fn.alterClass = function(removals, additions) {
    var patt, self;
    self = this;
    if (removals.indexOf('*') === -1) {
      self.removeClass(removals);
      if (!additions) {
        return self;
      } else {
        return self.addClass(additions);
      }
    }
    patt = new RegExp('\\s' + removals.replace(/\*/g, '[A-Za-z0-9-_]+').split(' ').join('\\s|\\s') + '\\s', 'g');
    self.each(function(i, it) {
      var cn;
      cn = ' ' + it.className + ' ';
      while (patt.test(cn)) {
        cn = cn.replace(patt, ' ');
      }
      it.className = $.trim(cn);
    });
    if (!additions) {
      return self;
    } else {
      return self.addClass(additions);
    }
  };

  (function($) {
    var $event, $special, resizeTimeout;
    $event = $.event;
    $special = void 0;
    resizeTimeout = void 0;
    $special = $event.special.debouncedresize = {
      setup: function() {
        $(this).on('resize', $special.handler);
      },
      teardown: function() {
        $(this).off('resize', $special.handler);
      },
      handler: function(event, execAsap) {
        var args, context, dispatch;
        context = this;
        args = arguments;
        dispatch = function() {
          event.type = 'debouncedresize';
          $event.dispatch.apply(context, args);
        };
        if (resizeTimeout) {
          clearTimeout(resizeTimeout);
        }
        if (execAsap) {
          dispatch();
        } else {
          resizeTimeout = setTimeout(dispatch, $special.threshold);
        }
      },
      threshold: 150
    };
  })(jQuery);

  MKBL.checkArray = function(needle) {
    var indexOf;
    if (typeof Array.prototype.indexOf === 'function') {
      indexOf = Array.prototype.indexOf;
    } else {
      indexOf = function(needle) {
        var i, index;
        i = -1;
        index = -1;
        i = 0;
        while (i < this.length) {
          if (this[i] === needle) {
            index = i;
            break;
          }
          i++;
        }
        return index;
      };
    }
    return indexOf.call(this, needle);
  };


  /**
   * Converts matrix like rgba or transforms to an array
   */

  MKBL.matrixToArray = function(str) {
    return str.match(/(-?[0-9\.]+)/g);
  };


  /**
   * This creates equal height children relative to the parent
   * @param  {[type]} container        the container of the elements that will be equal height
   * @param  {[type]} eqHeightChildren the elements that will be equal height
   * @param  {[type]} cutoff           the window width cutoff for the elements to be equal height
   */

  MKBL.equalheight = function(container, eqHeightChildren, cutoff) {
    var $child, t, t_elem;
    if ($(window).width() > cutoff) {
      t = 0;
      t_elem = void 0;
      $child = $(container).find(eqHeightChildren);
      $child.each(function() {
        var $this;
        $this = $(this);
        if ($this.outerHeight() > t) {
          t_elem = this;
          t = $this.outerHeight();
          return t;
        }
      });
      return $child.css('min-height', t);
    }
  };

  MKBL.overlay = function() {
    return MKBL.activationToggle($('.cogv1-page'), 'overlay-is-on');
  };


  /**
   * This controls the social slider interaction
   */

  MKBL.socialSlider = function($this) {
    var $caret, $thisMobileRelatedContent, $thisRelatedContent, prevIndex, thisIndex;
    $caret = $('#js-social-caret');
    $thisRelatedContent = $('.social-group__groups--text');
    $thisMobileRelatedContent = $('.social-group__groups--small .social-group__groups');
    thisIndex = $this.index();
    prevIndex = $('.social-group__icon.is-active').index();
    $('.social-group__icon').removeClass('is-long-distance').removeClass('is-active');
    $caret.removeClass('is-long-distance');
    $thisRelatedContent.removeClass('is-long-distance');
    if (Math.abs(prevIndex - thisIndex) > 1 && $(window).outerWidth > 540) {
      $this.addClass('is-long-distance');
      $('.social-group__icon').eq(1).addClass('is-long-distance');
      $caret.addClass('is-long-distance');
      $thisRelatedContent.addClass('is-long-distance');
    }
    $this.addClass('is-active');
    $thisRelatedContent.removeClass('is-active');
    $thisMobileRelatedContent.removeClass('is-active');
    $thisRelatedContent.eq(thisIndex).addClass('is-active');
    $thisMobileRelatedContent.eq(thisIndex).addClass('is-active');
    switch (thisIndex) {
      case 0:
        return $caret.removeClass('is-right').addClass('is-left');
      case 2:
        return $caret.removeClass('is-left').addClass('is-right');
      default:
        return $caret.removeClass('is-right').removeClass('is-left');
    }
  };


  /**
   * [flowBoxSliderSetup description]
   * @return {[type]} [description]
   */

  MKBL.flowBoxSliderSetup = function() {
    var $slideIndicator, flowBoxSlideAnimation, numOfSlides;
    numOfSlides = $('.flow-box-slider').find('.flow-box-slider-group').length;
    $slideIndicator = $('.slider-nav-indicator');
    $slideIndicator.width((1 / numOfSlides) * 100 + '%');

    /**
    	 * [flowBoxSlideAnimation description]
    	 * @param  {[type]} translation translation distance
    	 * @param  {[type]} duration    animation duration
    	 * @param  {[type]} delay       delay time
     */
    flowBoxSlideAnimation = function(translation, duration, delay) {
      return $slideIndicator.velocity({
        translateX: translation
      }, {
        duration: duration || 900,
        easing: [300, 28],
        delay: delay || 150
      });
    };

    /**
    	 * [flowBoxSlider description]
    	 * @param  {[type]} $slider      the parent slider element
    	 * @param  {[type]} $slides      the child slides
    	 * @param  {[type]} $activeSlide the slide that is visible
    	 * @param  {[type]} direction    the direction of the slide animation
     */
    return MKBL.flowBoxSlider = function($slider, $slides, $activeSlide, direction) {
      var $slideNewActive, $slideNextIndex, $slidePrevIndex;
      $slideIndicator.setWidth = $slideIndicator.width();
      $slideIndicator.position = Number(MKBL.matrixToArray($slideIndicator.css('transform'))[4]);
      if (direction === 'next') {
        $slideNewActive = ($activeSlide.index() + 1) % numOfSlides;
        if ($slideNewActive === 0) {
          flowBoxSlideAnimation($slideIndicator.position += $slideIndicator.setWidth, 300, 1);
          $slideIndicator.velocity({
            translateX: -$slideIndicator.setWidth
          }, {
            duration: 0,
            easing: "linear",
            delay: 1
          });
          flowBoxSlideAnimation(0, 550, 1);
        } else {
          flowBoxSlideAnimation($slideIndicator.position += $slideIndicator.setWidth);
        }
      } else {
        $slideNewActive = ($activeSlide.index() - 1) % numOfSlides;
        if ($slideNewActive === -1) {
          flowBoxSlideAnimation($slideIndicator.position -= $slideIndicator.setWidth, 300, 1);
          $slideIndicator.velocity({
            translateX: $slideIndicator.setWidth * numOfSlides
          }, {
            duration: 0,
            easing: "linear",
            delay: 1
          });
          flowBoxSlideAnimation($slideIndicator.setWidth * (numOfSlides - 1), 550, 1);
        } else {
          flowBoxSlideAnimation($slideIndicator.position -= $slideIndicator.setWidth);
        }
      }
      $slideNextIndex = ($slideNewActive + 1) % numOfSlides;
      $slidePrevIndex = ($slideNewActive - 1) % numOfSlides;
      if (!$slider.hasClass('locked')) {
        $slider.addClass('locked');
        $slides.removeClass('is-active').removeClass('is-prev').removeClass('is-next');
        $slides.eq($slideNewActive).addClass('is-active');
        $slides.eq($slidePrevIndex).addClass('is-prev');
        $slides.eq($slideNextIndex).addClass('is-next');
        return setTimeout(function() {
          return $slider.removeClass('locked');
        }, 750);
      }
    };
  };


  /**
   * Flyout interaction for the mobile profile bar
   * @param  {[type]} $this       the icon being clicked
   * @param  {[type]} $flyoutType which flyout is being called?
   */

  MKBL.profileCompactFlyout = function($this, $flyoutType) {
    var $flyout, $module;
    $module = $this.closest('.compact-profile-box-module');
    $flyout = $module.find('.compact-profile-box__flyout--' + $flyoutType);
    if ($flyout.hasClass('is-active')) {
      return $('.compact-profile-box__flyout').removeClass('is-active');
    } else {
      $('.compact-profile-box__flyout').removeClass('is-active');
      return $flyout.addClass('is-active');
    }
  };


  /**
   * This controls the settings and message alert flyouts associated with the desktop profile box module
   * @param  {[type]} $this           the icon clicked
   * @param  {[type]} $flyoutType     which flyout is it?
   * @param  {[type]} $activeFlyout 	which flyout is currently active
   */

  MKBL.profileFlyout = function($this, $flyoutType) {
    var $activeFlyout, $flyout, $module;
    $module = $this.closest('.profile-box-module');
    $activeFlyout = $this.closest('.profile-box-module').find('.profile-box-flyout.is-holding');
    $flyout = $this.closest('.profile-box-module').find('.profile-box-flyout--' + $flyoutType);
    if (!$module.hasClass('is-animating')) {
      if ($flyout.hasClass('is-holding')) {
        $module.addClass('is-animating');
        $flyout.removeClass('is-active').removeClass('is-holding');
        return setTimeout(function() {
          $flyout.addClass('is-closed');
          return $module.removeClass('is-animating');
        }, 1001);
      } else {
        $module.addClass('is-animating');
        $activeFlyout.removeClass('is-active').removeClass('is-holding');
        setTimeout(function() {
          return $activeFlyout.addClass('is-closed');
        }, 1001);
        $flyout.addClass('is-active').removeClass('is-closed');
        return setTimeout(function() {
          $flyout.addClass('is-holding').removeClass('is-active');
          return $module.removeClass('is-animating');
        }, 1001);
      }
    }
  };


  /**
   * Opens the modal
   * @param  {[type]} $this button that opened the modal
   */

  MKBL.modal = function($this) {
    var $modal, $tooltip;
    $modal = $($this.data('modal-id').toString());
    $tooltip = $modal.find('.modal-tip');
    if ($modal.hasClass('is-hidden')) {
      $tooltip.css({
        'left': $this.offset().left - ($(window).width() - $modal.outerWidth()) / 2,
        'right': 'auto'
      });
      $modal.css({
        'top': $this.offset().top - $modal.outerHeight() - 95
      }).removeClass('is-reverse').removeClass('is-hidden');
      $tooltip.css({
        'bottom': '-1.3rem',
        'top': 'auto'
      });
      return $('html, body').animate({
        scrollTop: $modal.position().top
      }, 'slow');
    } else {
      return $modal.addClass('is-hidden');
    }
  };


  /**
   * Opens the dropdown for the content editable module
   * @param  {[type]} $dropdown the dropdown being called
   */

  MKBL.contenteditableDropdown = function($dropdown, $trigger) {
    var $li, dropdownHeight;
    $li = $dropdown.find('li');
    dropdownHeight = $li.length * $li.outerHeight();
    if (dropdownHeight > 342) {
      dropdownHeight = 372;
      setTimeout(function() {
        return $dropdown.perfectScrollbar({
          suppressScrollX: true
        });
      }, 900);
    }
    if ($dropdown.height() === 0 || $dropdown.height() === null) {
      MKBL.activationOn($trigger);
      return $dropdown.velocity({
        height: dropdownHeight
      }, {
        duration: 600,
        easing: [300, 30],
        delay: 0,
        complete: function() {
          return $(this).addClass('is-active');
        }
      });
    } else {
      MKBL.activationOff($trigger);
      return $dropdown.velocity({
        height: 0
      }, {
        duration: 600,
        easing: [300, 30],
        delay: 0,
        complete: function() {
          return $(this).removeClass('is-active');
        }
      });
    }
  };

  MKBL.contenteditableMobileScroll = function($this) {
    return $('html, body').animate({
      scrollTop: $this.position().top
    }, 'slow');
  };

  MKBL.contenteditableDropdownAutocomplete = function($this) {
    var $dropdown, $trigger, matchingLetters, pattern, searchInputText;
    $trigger = $this.closest('.js-dropdown-option-parent').find('.js-dropdown-trigger');
    if ($this.closest('.js-dropdown-option-parent').find('.contenteditable-dropdown').length) {
      $dropdown = $this.closest('.js-dropdown-option-parent').find('.contenteditable-dropdown');
      if ($dropdown.height() === 0 || $dropdown.height() === null) {
        MKBL.contenteditableDropdown($dropdown, $trigger);
      }
      searchInputText = $this.html().replace(/^\s+|\s+$/g, '');
      if (searchInputText !== '' && searchInputText !== ' ') {
        pattern = new RegExp(searchInputText, 'gi');
      }
      matchingLetters = null;
      return $dropdown.find('.js-dropdown-option').each(function() {
        matchingLetters = $(this).text();
        matchingLetters = matchingLetters.replace(pattern, function($1) {
          return '<span>' + $1 + '</span>';
        });
        return $(this).html(matchingLetters);
      });
    }
  };

  MKBL.searchAutocomplete = function($input, $autoSuggestListItem) {
    var matchingLetters, pattern, searchInputText;
    searchInputText = $input.val().replace(/^\s+|\s+$/g, '');
    if (searchInputText !== '' && searchInputText !== ' ') {
      pattern = new RegExp(searchInputText, 'gi');
    }
    matchingLetters = null;
    return $autoSuggestListItem.each(function() {
      matchingLetters = $(this).text();
      matchingLetters = matchingLetters.replace(pattern, function($1) {
        return '<span>' + $1 + '</span>';
      });
      return $(this).html(matchingLetters);
    });
  };


  /**
   * Fills the content editable section with the selected dropdown option
   * @param  {[type]} $this the button clicked
   */

  MKBL.contenteditableDropdownSelect = function($selectedOption) {
    var $contenteditable, $contenteditableParent, maxWidth;
    if ($(window).width() * 0.7 > 840) {
      maxWidth = 840;
    } else {
      maxWidth = $(window).width() * 0.7;
    }
    $selectedOption.siblings().removeClass('is-active');
    $selectedOption.addClass('is-active');
    $contenteditableParent = $selectedOption.closest('.js-dropdown-option-parent');
    $contenteditable = $selectedOption.closest('.js-dropdown-option-parent').find('[contenteditable]');
    MKBL.activationOff($('js-dropdown-trigger'));
    $contenteditableParent.find('.js-dropdown-option-holder').each(function() {
      if ($(this).is('input')) {
        return $(this).val($selectedOption.text());
      } else {
        return $(this).text($selectedOption.text());
      }
    });
    if ($selectedOption.text() !== $contenteditableParent.find('.js-dropdown-option-holder').data('default')) {
      $contenteditableParent.addClass('is-filled');
    } else {
      $contenteditableParent.removeClass('is-filled');
    }
    if ($contenteditable.prop('scrollWidth') < maxWidth) {
      $contenteditable.css('min-width', '100px');
      return setTimeout(function() {
        return $contenteditable.css('min-width', $contenteditable.width());
      }, 900);
    }
  };


  /**
   * animation for the content editable div on click
   * @param  {[type]} $this the content editable div
   */

  MKBL.prepareContenteditable = function($this) {
    $this.closest('.is-editable').addClass('is-active');
    if (!$this.closest('.is-editable').hasClass('is-filled')) {
      return $this.text('');
    }
  };


  /**
   * animation for leaving focus of the content editable div
   */

  MKBL.endContenteditable = function() {
    var maxWidth;
    if ($(window).width() * 0.7 > 840) {
      maxWidth = 840;
    } else {
      maxWidth = $(window).width() * 0.7;
    }
    MKBL.activationOff($('[contenteditable]'));
    return $('[contenteditable]').each(function() {
      var $this;
      $this = $(this);
      $this.siblings('input.hidden').val($this.text());
      if ($this.text() === '') {
        $this.text($this.data('placeholder')).closest('.is-editable').removeClass('is-filled').removeClass('is-active');
        $this.css('min-width', '100px');
        return setTimeout(function() {
          return $this.css('min-width', $this.width());
        }, 900);
      } else {
        if ($this.text() !== $this.data('placeholder')) {
          $this.closest('.is-editable').addClass('is-filled');
        }
        if ($this.prop('scrollWidth') < maxWidth && $this.css('min-width') !== $this.width()) {
          $this.css('min-width', '100px');
          return setTimeout(function() {
            return $this.css('min-width', $this.width());
          }, 900);
        }
      }
    });
  };


  /**
   * Sets up the content editable div on load
   */

  MKBL.setupContenteditable = function() {
    return $('[contenteditable]').each(function() {
      var $this, maxWidth;
      $this = $(this).closest('.is-editable').find('.contenteditable__wrapper');
      if ($(window).width() * 0.7 > 840) {
        maxWidth = 840;
      } else {
        maxWidth = $(window).width() * 0.7;
      }
      $this.css('max-width', maxWidth).perfectScrollbar();
      if ($this.outerWidth() < maxWidth) {
        $this.css('min-width', $this.outerWidth());
      } else {
        $this.css('min-width', maxWidth);
      }
      return $this.perfectScrollbar();
    });
  };

  MKBL.playVideo = function(e, $this) {
    var $parent, $video;
    console.log('this');
    $parent = $this.closest('.video-section');
    $video = $parent.find('iframe');
    $parent.addClass('is-active');
    setTimeout(function() {
      return $video[0].src += '&autoplay=1';
    }, 300);
    return e.preventDefault();
  };

  MKBL.stopVideo = function(e, $this) {
    var $video, videoURL;
    $video = $($this).find('iframe');
    videoURL = $video.attr('src');
    console.log(videoURL);
    videoURL.replace("&autoplay=1", "");
    $video.attr('src', '');
    setTimeout(function() {
      return $video.attr('src', videoURL);
    }, 1);
    return e.preventDefault();
  };

  MKBL.activationToggle = function($parent, cssClass) {
    cssClass = cssClass || 'is-active';
    return $parent.toggleClass(cssClass);
  };

  MKBL.activationOn = function($parent, cssClass) {
    cssClass = cssClass || 'is-active';
    if (!$parent.hasClass(cssClass)) {
      return $parent.addClass(cssClass);
    }
  };

  MKBL.activationOff = function($parent) {
    var cssClass;
    cssClass = cssClass || 'is-active';
    return $parent.removeClass(cssClass);
  };

  MKBL.articleNavWaypoints = function() {
    MKBL.articleNavWaypoint = $('.cogv1_article-nav').waypoint({
      offset: $(window).height() / 2,
      handler: function(direction) {
        if (direction === 'down') {
          return $(this.element).addClass('is-scrolling').removeClass('is-bottom');
        } else {
          return $(this.element).removeClass('is-scrolling').removeClass('is-bottom');
        }
      }
    });
    MKBL.articleNavAlmostBottomWaypoint = $('.cogv1_article__footer-nav').waypoint({
      offset: ($(window).height() / 2) - ($('.cogv1_article-nav').height() * 2),
      handler: function(direction) {
        if (direction === 'down') {
          return $('.cogv1_article-nav').addClass('is-almost-bottom');
        } else {
          return $('.cogv1_article-nav').removeClass('is-almost-bottom');
        }
      }
    });
    MKBL.articleNavBottomWaypoint = $('.cogv1_article__footer-nav').waypoint({
      offset: ($(window).height() / 2) - $('.cogv1_article-nav').height(),
      handler: function(direction) {
        if (direction === 'down') {
          $('.cogv1_article__footer-nav__button').addClass('is-active');
          return $('.cogv1_article-nav').addClass('is-bottom').removeClass('is-scrolling');
        } else {
          $('.cogv1_article__footer-nav__button').removeClass('is-active');
          return $('.cogv1_article-nav').addClass('is-scrolling').removeClass('is-bottom');
        }
      }
    });
  };


  /**
   * COGNIZANT START EVENTS.JS
   */

  $('input').on('touchstart', function() {
    return $(this).focus();
  });

  $('.cogv1-smart-search__input').on('keyup', function() {
    if ($(this).val() !== '') {
      return MKBL.activationOn($('.cogv1-smart-search__icon--right'));
    } else {
      return MKBL.activationOff($('.cogv1-smart-search__icon--right'));
    }
  });

  $('.search-module--main .search__input').on('keyup', function() {
    if ($(this).val() !== '') {
      return MKBL.activationOn($('.search__CTA'));
    } else {
      return MKBL.activationOff($('.search__CTA'));
    }
  });

  $('.cogv1-smart-search__input').on('keyup', function(e) {
    console.log('this');
    MKBL.activationOn($('.cogv1-smart-search__dropdown'));
    MKBL.searchAutocomplete($(this), $('.cogv1-smart-search__dropdown .js-search-text'));
    if (!$('.cogv1-smart-search__dropdown .js-search-text').find('span').length) {
      MKBL.activationOff($('.cogv1-smart-search__dropdown'));
      return MKBL.activationOn($('.cogv1-smart-search__results'));
    }
  });

  $('.cogv1_article__save__list').on('click', function() {
    MKBL.activationOff($('.cogv1_article__save__list'));
    return MKBL.activationOn($(this));
  });

  $('[contenteditable]').on('click', function() {
    var $this;
    $this = $(this);
    return MKBL.prepareContenteditable($this);
  });

  $('body').on('focus', '[contenteditable]', function() {
    var $this;
    $this = $(this);
    $this.data('before', $this.html());
    return $this;
  }).on('blur keyup paste input', '[contenteditable]', function() {
    var $this;
    $this = $(this);
    if ($this.data('before') !== $this.html()) {
      $this.data('before', $this.html());
      $this.trigger('change');
      return MKBL.contenteditableDropdownAutocomplete($this);
    }
  }).on('keydown', '[contenteditable]', function(e) {
    var keyCode;
    keyCode = e.keyCode || e.which;
    if (keyCode === 13) {
      return e.preventDefault();
    }
  });

  $('.search-module').on('click', '.js-dropdown-trigger', function() {
    var $parent;
    $parent = $(this).closest('.search-module');
    return MKBL.activationToggle($parent, 'is-active');
  });

  $('.js-cogv1_icon-header__share-flyout__trigger, .article-mobile__share').on('click', function() {
    return MKBL.activationToggle($(this).siblings('.js-share-flyout'));
  });

  $('.js-dropdown-trigger').on('click', function() {
    var $dropdown, $trigger;
    $trigger = $(this);
    if ($(this).find('.contenteditable-dropdown').length) {
      $dropdown = $(this).closest('.contenteditable-dropdown');
    } else {
      $dropdown = $(this).siblings('.contenteditable-dropdown');
    }
    return MKBL.contenteditableDropdown($dropdown, $trigger);
  });

  $('.cogv1-smart-search__icon--right').on('click', function() {
    return MKBL.activationOn($('.cogv1-smart-search__results'));
  });

  $('.cogv1_search__favorites').on('click', function() {
    return MKBL.activationToggle($(this).closest('.cogv1_search__section-right').siblings('.cogv1_search__flyout'));
  });

  $('.cogv1_article-subhead__highlight .js-share-flyout__trigger').on('click', function() {
    MKBL.activationToggle($(this));
    MKBL.activationToggle($(this).siblings('.js-share-flyout'));
    return MKBL.activationToggle($(this).closest('.cogv1_article-subhead__highlight'));
  });

  $('.js-dropdown-option').on('click', function() {
    var $this;
    $this = $(this);
    return MKBL.contenteditableDropdownSelect($this);
  });

  $('.cogv1_article__save__add').on('click', function(e) {
    e.preventDefault();
    e.stopPropagation();
    MKBL.activationToggle($(this).children('.add-action'));
    return $('.add-action.is-active .cogv1_article__save__input').trigger('focus');
  });

  $('.js-toggle-save-overlay').on('click', function() {
    MKBL.activationToggle($(this).closest('.flow-box').find('.flow-box__folder-save'));
    if ($(this).hasClass('js-toggle-save-overlay__icon')) {
      return MKBL.activationOff($(this).closest('.flow-box').find('.flow-box__content .js-toggle-save-overlay'));
    }
  });

  $('.interactive-svg').on('click', function() {
    return MKBL.activationToggle($(this));
  });

  $('.js-edit-profile').on('click', function() {
    MKBL.activationToggle($('.edit-profile-overlay'));
    return MKBL.overlay();
  });

  $('.js-save-article').on('click', function() {
    MKBL.activationToggle($('.cogv1_article__save'));
    return MKBL.activationToggle($('.cogv1_article-subhead__save-article .interactive-svg'));
  });

  $('.js-smart-search').on('click', function() {
    MKBL.activationToggle($('.smart-search-overlay'));
    return MKBL.overlay();
  });

  $('.js-open-modal-module').on('click', function() {
    var $this;
    $this = $(this);
    return MKBL.modal($this);
  });

  $('.js-flow-box-flyout__trigger').on('click', function() {
    var $parent;
    $parent = $(this).closest('.flow-box__CTA');
    return MKBL.activationToggle($parent);
  });

  $('.js-search-share-flyout__trigger').on('click', function() {
    var $parent;
    $parent = $(this).closest('.cogv1_search__section-right');
    return MKBL.activationToggle($parent, 'flyout-is-active');
  });

  $('.js-share-flyout__trigger').on('click', function() {
    var $parent;
    $parent = $(this).closest('.search__share-flyout__wrapper');
    return MKBL.activationToggle($parent, 'flyout-is-active');
  });

  $('.compact-profile-box__aside .icon').on('click', function() {
    var $flyoutType, $this;
    $this = $(this);
    $flyoutType = $this.data('flyout');
    return MKBL.profileCompactFlyout($this, $flyoutType);
  });

  $('.profile-box__aside .icon').on('click', function() {
    var $flyoutType, $this;
    $this = $(this);
    $flyoutType = $this.data('flyout');
    return MKBL.profileFlyout($this, $flyoutType);
  });

  $('.slider-nav__control').on('click', function() {
    var $activeSlide, $slider, $slides, direction;
    $slider = $(this).closest('.flow-box-slider');
    $slides = $slider.find('.flow-box-slider-group');
    $activeSlide = $slider.find('.flow-box-slider-group.is-active');
    direction = 'prev';
    if ($(this).hasClass('is-right')) {
      direction = 'next';
    }
    return MKBL.flowBoxSlider($slider, $slides, $activeSlide, direction);
  });

  $('.share-icons-list .interactive-svg').on('click', function() {
    return MKBL.activationToggle($(this).closest('.share-icons-list'));
  });

  $('.social-group__icon').on('click', function() {
    var $this;
    $this = $(this);
    return MKBL.socialSlider($this);
  });

  $('.js-video-play').on('click', function(e) {
    var $this;
    $this = $(this);
    return MKBL.playVideo(e, $this);
  });

  $(document).on('click', function(event) {
    return MKBL.activationOff($('.cogv1-smart-search__dropdown'));
  });

  $(document).on('click touchstart', function(event) {
    if (!$(event.target).closest('.js-open-modal-module').length) {
      $('.modal-module').addClass('is-hidden');
    }
    if (!$(event.target).closest('.compact-profile-box__aside').length) {
      MKBL.activationOff($('.compact-profile-box__flyout'));
    }
    if (!$(event.target).closest('.js-dropdown-trigger').length) {
      MKBL.activationOff($('.js-dropdown-trigger'));
      $('.contenteditable-dropdown').velocity({
        height: 0
      }, {
        duration: 600,
        easing: [300, 30],
        delay: 0,
        complete: function() {
          return $(this).removeClass('is-active');
        }
      });
    }
    if (!$(event.target).closest('[contenteditable]').length && !$(event.target).closest('.is-editable .js-dropdown-option').length) {
      MKBL.endContenteditable();
    }
    if (!$(event.target).closest('.search-module .js-dropdown-trigger').length) {
      MKBL.activationOff($('.search-module'));
    }
    if (!$(event.target).closest('.js-video-play').length && !$(event.target).closest('.video-section').length) {
      $('.video-section').removeClass('is-active');
      return $('.video-section.is-active').each(function() {
        return MKBL.stopVideo(e, $(this));
      });
    }
  });

  $(function() {
    MKBL.flowBoxSliderSetup();
    MKBL.setupContenteditable();
    if ($(window).width() > 1024 && $('.cogv1_article-nav').length) {
      return MKBL.articleNavWaypoints();
    }
  });

  $(window).on('debouncedresize', function() {
    MKBL.equalheight('.main-header', '.js-equal-height', 1024);
    MKBL.equalheight('.social-group__groups', '.js-equal-height', 680);
    MKBL.equalheight('.three-group__groups', '.three-group__content', 940);
    MKBL.flowBoxSliderSetup();
    $('.modal-module').addClass('is-hidden');
    MKBL.setupContenteditable();
    if ($(window).width() > 1024 && $('.cogv1_article-nav').length) {
      return MKBL.articleNavWaypoints();
    }
  });

  $(window).on('load', function() {
    MKBL.equalheight('.main-header', '.js-equal-height', 1024);
    MKBL.equalheight('.social-group__groups', '.js-equal-height', 680);
    return MKBL.equalheight('.three-group__groups', '.three-group__content', 940);
  });

  MKBL.listFilter = function(input, list) {
    return $(input).on('keyup', function(e) {
      var filter, keyCode;
      keyCode = e.keyCode || e.which;
      if ($.inArray(keyCode, [9, 13, 38, 40]) < 0) {
        filter = $(this).val();
        if (filter && filter !== '') {
          $('.mkbl-form-hint.is-select').removeClass('is-displayed');
          $(list).find('li').removeClass('is-active');
          $(list).find('li:not(:contains(' + filter + '))').removeClass('not-filtered');
          $(list).find('li:contains(' + filter + ')').addClass('not-filtered');
          return $(list).find('li.not-filtered').eq(0).addClass('is-active');
        } else {
          $(list).find('li').addClass('not-filtered').removeClass('is-active');
          $('.mkbl-form-hint.is-select').addClass('is-displayed');
          return $('.mkbl-form-hint.is-input').removeClass('is-displayed');
        }
      }
    });
  };

  MKBL.currentField = null;

  MKBL.timeout = null;

  MKBL.waitToShow = 0;

  MKBL.saveField = function(currentField) {
    var currentFieldVal, hasError, options;
    hasError = false;
    currentFieldVal = $('#enter-' + currentField).find('.mkbl-main-input').val();
    if (!$('#enter-' + currentField).find('.mkbl-select-bg').length) {
      if (currentFieldVal === '') {
        hasError = true;
        $('#enter-' + currentField).find('input').addClass('has-error').trigger('touchstart');
        $('.mkbl-form-progress-bar').addClass('has-error');
        $('#' + currentField).removeClass('is-valid');
      }
    } else if ($('#enter-' + currentField).find('.mkbl-select-bg').length) {
      options = [];
      $('#enter-' + currentField).find('.mkbl-select-option').each(function() {
        var optionText;
        optionText = $(this).text();
        return options.push(optionText);
      });
      if (MKBL.checkArray.call(options, $('#enter-' + currentField).find('.mkbl-main-input').val()) === -1) {
        hasError = true;
        $('#enter-' + currentField).find('input').addClass('has-error').trigger('touchstart');
        $('.mkbl-form-progress-bar').addClass('has-error');
        $('#' + currentField).removeClass('is-valid');
      }
    }
    if (!hasError) {
      $('#' + currentField + ' .mkbl-subinput').text(currentFieldVal);
      $('#' + currentField).removeClass('is-active').removeClass('is-typing').addClass('is-filled').addClass('is-valid');
      $('.mkbl-form-progress-bar').removeClass('has-error');
      $('#enter-' + currentField).find('.mkbl-select-bg').removeClass('is-open');
      $('#' + currentField).find('.mkbl-select-bg').removeClass('is-open');
      if ($('#enter-' + currentField).find('.mkbl-select-bg').length) {
        setTimeout((function() {
          return $('#enter-' + currentField).addClass('is-hidden');
        }), 400);
        MKBL.waitToShow = 400;
      } else {
        $('#enter-' + currentField).addClass('is-hidden');
        MKBL.waitToShow = 0;
      }
      MKBL.setProgress();
    }
    return !hasError;
  };

  MKBL.prepareField = function(nextField) {
    $('.mkbl-form-complete').removeClass('is-active');
    $('.mkbl-form-hint.is-select').removeClass('is-displayed');
    $('.mkbl-form-hint.is-input').removeClass('is-displayed');
    if ($('#enter-' + nextField).find('.mkbl-select-bg').length) {
      if (MKBL.currentField !== nextField) {
        setTimeout((function() {
          $('#enter-' + nextField).removeClass('is-hidden');
          return setTimeout((function() {
            if ($('#enter-' + nextField).index() > 0) {
              $('#enter-' + nextField).find('.mkbl-main-input').trigger('touchstart');
            }
            $('.mkbl-form-hint.is-select').addClass('is-displayed');
            MKBL.listFilter('.mkbl-sselect', '.mkbl-select-bg.is-open');
            return $('#enter-' + nextField).find('.mkbl-select-bg').addClass('is-open');
          }), 1);
        }), MKBL.waitToShow);
      }
    } else {
      setTimeout((function() {
        $('#enter-' + nextField).removeClass('is-hidden');
        return setTimeout((function() {
          if ($('#enter-' + nextField).index() > 0) {
            return $('#enter-' + nextField).find('.mkbl-main-input').trigger('touchstart');
          }
        }), 1);
      }), MKBL.waitToShow);
    }
    $('#' + nextField).addClass('is-active').removeClass('is-clean');
    if ($('#enter-' + nextField).find('.mkbl-select-bg').length) {
      MKBL.waitToShow = 400;
    } else {
      MKBL.waitToShow = 0;
    }
    MKBL.currentField = nextField;
    return MKBL.currentField;
  };

  MKBL.moveToField = function(nextField) {
    var currentF, success;
    if (MKBL.currentField === nextField) {
      return;
    }
    currentF = MKBL.currentField;
    success = true;
    if (currentF !== null && $('#' + currentF).hasClass('is-dirty')) {
      success = MKBL.saveField(currentF);
    } else {
      if ($('#enter-' + currentF).find('.mkbl-select-bg').length) {
        $('#enter-' + currentF).find('.mkbl-select-bg').removeClass('is-open');
        $('#' + currentF).find('.mkbl-select-bg').removeClass('is-open');
        setTimeout((function() {
          return $('#enter-' + currentF).addClass('is-hidden');
        }), 400);
        MKBL.waitToShow = 400;
      } else {
        $('#enter-' + currentF).addClass('is-hidden');
        MKBL.waitToShow = 0;
      }
      $('#' + currentF).removeClass('is-active').removeClass('is-typing').addClass('is-filled');
    }
    if (success) {
      return MKBL.prepareField(nextField);
    }
  };

  MKBL.requestNextField = function() {
    var nextField, success;
    if (MKBL.currentField !== null) {
      success = MKBL.saveField(MKBL.currentField);
      if (success) {
        if ($('.mkbl-form-subfields .mkbl-fieldset.is-valid').length === MKBL.progressDenominator) {
          return MKBL.showSubmit();
        } else {
          nextField = $('.mkbl-form-subfields .mkbl-fieldset.is-valid').last().next().attr('id');
          return MKBL.prepareField(nextField);
        }
      }
    } else {
      return MKBL.prepareField('field-name');
    }
  };

  MKBL.showSubmit = function() {
    $('.mkbl-select-bg').removeClass('is-open');
    $('.mkbl-form-hint.is-select').removeClass('is-displayed');
    $('.mkbl-form-hint.is-input').removeClass('is-displayed');
    $('.mkbl-form-button').addClass('is-active').trigger('touchstart');
    return setTimeout((function() {
      $('.mkbl-form-main-field fieldset').addClass('is-hidden');
      return $('.mkbl-form-complete').addClass('is-active');
    }), 400);
  };


  /* This sets the progress bar after entering a value in the form */

  MKBL.setProgress = function() {
    return setTimeout((function() {
      var progressActive, progressDividend, progressFilled;
      progressFilled = $('.mkbl-form-subfields .mkbl-fieldset.is-filled').length;
      progressActive = $('.mkbl-form-subfields .mkbl-fieldset.is-filled.is-active').length;
      progressDividend = progressFilled - progressActive;
      return $('.mkbl-form-progress-bar-progress').css('width', ((progressDividend / MKBL.progressDenominator) * 100) + '%');
    }), 1);
  };

  MKBL.formInit = function() {
    MKBL.prepareField('field-name');
    MKBL.progressDenominator = $('.mkbl-form-subfields .mkbl-fieldset').length;
    $('.mkbl-form-subfields .mkbl-fieldset').on('click', function() {
      return MKBL.moveToField($(this).attr('id'));
    });
    $('.mkbl-main-input').on('keydown', function() {
      var animateEllipse, deanimateEllipse, thisField;
      thisField = $(this).closest('fieldset').attr('id').substring(6);
      $('#' + thisField).addClass('is-dirty');
      $('.mkbl-form-main-field .mkbl-fieldset').find('input').removeClass('has-error');
      $('.mkbl-form-hint.is-input').addClass('is-displayed');
      $('.mkbl-form-progress-bar').removeClass('has-error');

      /* This animates the input dots */
      deanimateEllipse = function() {
        return $('#' + thisField).removeClass('is-typing');
      };
      animateEllipse = function() {
        return $('#' + thisField).addClass('is-typing');
      };
      animateEllipse();
      if (MKBL.timeout) {
        clearTimeout(MKBL.timeout);
        MKBL.timeout = null;
      }
      MKBL.timeout = setTimeout(deanimateEllipse, 1500);
      return MKBL.timeout;
    });

    /* removes hints to selects */
    $('.mkbl-main-input').on('blur', function() {
      return $('.mkbl-form-hint.is-input').removeClass('is-displayed');
    });

    /* the form button trigger */
    $('.js-form-next').on('click', function(e) {
      var thisField;
      MKBL.requestNextField();
      thisField = $(this).closest('fieldset').attr('id').substring(6);
      return thisField;
    });
    $(window).on('keydown', function(e) {
      var keyCode, selectActive, thisField;
      if ($('#enter-' + MKBL.currentField).length) {
        thisField = $('#enter-' + MKBL.currentField).attr('id').substring(6);
        keyCode = e.keyCode || e.which;
        if (keyCode === 9) {
          e.preventDefault();
        }

        /* Tab and Submit */
        if (keyCode === 9 || keyCode === 13) {
          if (!$('.mkbl-form-button').is(':focus')) {
            e.preventDefault();
            if ($('.mkbl-form').find('.mkbl-select-bg.is-open .is-active').length) {
              $('#enter-' + MKBL.currentField + ' .mkbl-main-input').val($('.mkbl-select-bg.is-open .is-active').text());
            }
            setTimeout((function() {
              return MKBL.requestNextField();
            }), 1);
          }
        }

        /* Up Arrow */
        if (keyCode === 40) {
          e.preventDefault();
          $('.mkbl-form-hint.is-select').removeClass('is-displayed');
          $('.mkbl-form-hint.is-input').addClass('is-displayed');
          if ($('.mkbl-form').find('.mkbl-select-bg.is-open .is-active').length) {
            selectActive = $('.mkbl-form').find('.mkbl-select-bg.is-open .is-active');
            selectActive.removeClass('is-active');
            selectActive.next().addClass('is-active');
            $('#enter-' + MKBL.currentField).find('input').removeClass('has-error');
            $('.mkbl-form-progress-bar').removeClass('has-error');
          } else {
            selectActive = $('.mkbl-form').find('.mkbl-select-bg.is-open .mkbl-select-option:first-of-type');
            $('.mkbl-select-bg.is-open .mkbl-select-option:first-of-type').addClass('is-active');
          }
          $('#enter-' + MKBL.currentField + ' .mkbl-main-input').val(selectActive.next().text());
        }

        /* Down Arrow */
        if (keyCode === 38) {
          e.preventDefault();
          $('.mkbl-form-hint.is-select').removeClass('is-displayed');
          $('.mkbl-form-hint.is-input').addClass('is-displayed');
          if ($('.mkbl-form').find('.mkbl-select-bg.is-open .is-active').length) {
            selectActive = $('.mkbl-form').find('.mkbl-select-bg.is-open .is-active');
            selectActive.removeClass('is-active');
            selectActive.prev().addClass('is-active');
            $('#enter-' + MKBL.currentField).find('input').removeClass('has-error');
            $('.mkbl-form-progress-bar').removeClass('has-error');
          } else {
            selectActive = $('.mkbl-form').find('.mkbl-select-bg.is-open .mkbl-select-option:last-of-type');
            $('.mkbl-select-bg.is-open .mkbl-select-option:last-of-type').addClass('is-active');
          }
          return $('#enter-' + MKBL.currentField + ' .mkbl-main-input').val(selectActive.prev().text());
        }
      }
    });
    $('.mkbl-select-option').on('click', function() {
      var selectOption;
      selectOption = $(this).text();
      $('#enter-' + MKBL.currentField + ' .mkbl-sselect').val(selectOption);
      return MKBL.requestNextField();
    });
    return $('.mkbl-select-option').on('mouseover', function() {
      $('.mkbl-select-option').addClass('not-filtered').removeClass('is-active');
      $(this).addClass('is-active');
      $('#enter-' + MKBL.currentField + ' .mkbl-main-input').val($(this).text());
      $('#enter-' + MKBL.currentField).find('input').removeClass('has-error');
      return $('.mkbl-form-progress-bar').removeClass('has-error');
    });
  };

  $(function() {
    return MKBL.formInit();
  });

}).call(this);
