require('coffee-script').register();
require('./build/gulp.coffee');
